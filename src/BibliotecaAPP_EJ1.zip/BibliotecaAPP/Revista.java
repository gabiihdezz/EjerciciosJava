package BibliotecaAPP;

public class Revista extends Publicaciones{

	public Revista(String nombre, String autor, int anho) {
		super(nombre, autor, anho);
		// TODO Auto-generated constructor stub
	}

}
