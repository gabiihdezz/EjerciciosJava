package BibliotecaAPP;

public class Libro extends Publicaciones {

	public Libro(String nombre, String autor, int anho) {
		super(nombre, autor, anho);
		// TODO Auto-generated constructor stub
	}
	
}
